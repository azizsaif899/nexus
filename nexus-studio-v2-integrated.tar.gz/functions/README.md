# App: api

## Purpose

[TODO: Describe the purpose of the `api` application.]

## Getting Started

To serve this application in development mode, run the following command:

```bash
nx serve api
```
