export class AppModule {
  constructor() {
    // Removed console.log
  }
}
