'use client'

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

const faqs = [
    {
        question: "How does AzizSys help automate me?",
        answer: "AzizSys uses advanced AI models to learn your repetitive tasks and automate them for you. You can connect your favorite apps and build workflows in our visual editor without writing a single line of code."
    },
    {
        question: "Can I integrate Sola with my existing tools?",
        answer: "Yes, AzizSys integrates with hundreds of popular apps like Slack, Google Sheets, Salesforce, and more. Our API also allows you to build custom integrations."
    },
    {
        question: "Is AzizSys suitable for small businesses?",
        answer: "Absolutely! AzizSys is designed to be scalable. Our affordable plans and easy-to-use interface make it a great fit for small businesses looking to improve their efficiency."
    },
    {
        question: "How secure is my data with AzizSys?",
        answer: "We take data security very seriously. All your data is encrypted both at rest and in transit. We are fully GDPR compliant and use industry-standard security practices."
    },
    {
        question: "Do I need coding skills to use AzizSys?",
        answer: "Not at all! Our visual workflow builder is completely drag-and-drop. Anyone can build powerful automations with AzizSys, no coding skills required."
    }
]

const FAQSection = () => {
  return (
    <section id="faq" className="py-20 md:py-32 bg-slate-950">
      <div className="container max-w-screen-2xl mx-auto px-4">
        <div className="text-center">
            <p className="text-sm font-semibold uppercase tracking-widest text-blue-400">FAQ</p>
            <h2 className="mt-4 text-4xl font-extrabold tracking-tight text-white sm:text-5xl">Frequently Asked Questions</h2>
            <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-400">
                Have a different question? <a href="mailto:support@azizsys.com" className="text-blue-400 hover:underline">Contact us</a>.
            </p>
        </div>

        <div className="mt-12 max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, i) => (
                    <AccordionItem key={i} value={`item-${i+1}`}>
                        <AccordionTrigger className="text-white text-left">{faq.question}</AccordionTrigger>
                        <AccordionContent className="text-slate-400">
                           {faq.answer}
                        </AccordionContent>
                    </AccordionItem>
                ))}
            </Accordion>
        </div>
      </div>
    </section>
  )
}

export default FAQSection;