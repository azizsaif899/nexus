import { ChatInterface } from './components/ChatInterface';

export default function HomePage() {
  return <ChatInterface />;
}