const { getJestProjects } = require('@nx/jest');

module.exports = {
  projects: getJestProjects(),
  preset: '@nx/jest/preset'
};