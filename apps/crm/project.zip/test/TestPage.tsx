import React, { useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Badge } from '../components/ui/badge';
import {
  CheckCircle2,
  XCircle,
  Clock,
  Play,
  Eye,
  Smartphone,
  Palette,
  Zap,
  TestTube,
  FileCode,
  Activity,
  Monitor,
  Sun,
  Moon,
} from 'lucide-react';

// Import existing test components
import { ChartsTest } from './components/ChartsTest';
import { DnDTest } from './components/DnDTest';
import { RTLTest } from './components/RTLTest';
import { ThemeTest } from './components/ThemeTest';
import { UIComponentsTest } from './components/UIComponentsTest';

// Import new test specs
import { ThemeTestRunner } from './specs/theme.spec';
import { ColorsTestRunner } from './specs/colors.spec';
import { TailwindTestRunner } from './specs/tailwind.spec';
import { VisualRegressionTestRunner } from './specs/visual-regression.spec';
import { ComponentsTestRunner } from './specs/components.spec';
import { ResponsiveTestRunner } from './specs/responsive.spec';
import { FontsIconsTestRunner } from './specs/fonts-icons.spec';
import { AccessibilityTestRunner } from './specs/accessibility.spec';
import { PerformanceTestRunner } from './specs/performance-visual.spec';

type TestStatus = 'idle' | 'running' | 'passed' | 'failed';

interface TestSuite {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  category: 'design' | 'interaction' | 'performance' | 'e2e';
  status: TestStatus;
  component: React.ComponentType;
}

export default function TestPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [testSuites, setTestSuites] = useState<TestSuite[]>([
    {
      id: 'theme',
      name: 'اختبار الثيم',
      description: 'اختبار Dark/Light mode والألوان',
      icon: <Palette className="w-5 h-5" />,
      category: 'design',
      status: 'idle',
      component: ThemeTestRunner,
    },
    {
      id: 'colors',
      name: 'اختبار الألوان',
      description: 'التحقق من CSS Variables والألوان',
      icon: <Palette className="w-5 h-5" />,
      category: 'design',
      status: 'idle',
      component: ColorsTestRunner,
    },
    {
      id: 'tailwind',
      name: 'اختبار Tailwind',
      description: 'التحقق من تحميل Tailwind classes',
      icon: <FileCode className="w-5 h-5" />,
      category: 'design',
      status: 'idle',
      component: TailwindTestRunner,
    },
    {
      id: 'visual-regression',
      name: 'اختبار التصميم البصري',
      description: 'مقارنة لقطات الشاشة',
      icon: <Eye className="w-5 h-5" />,
      category: 'design',
      status: 'idle',
      component: VisualRegressionTestRunner,
    },
    {
      id: 'components',
      name: 'اختبار المكونات',
      description: 'عرض المكونات مع الأنماط الصحيحة',
      icon: <TestTube className="w-5 h-5" />,
      category: 'interaction',
      status: 'idle',
      component: ComponentsTestRunner,
    },
    {
      id: 'responsive',
      name: 'اختبار الاستجابة',
      description: 'التصميم على أحجام مختلفة ودعم RTL',
      icon: <Smartphone className="w-5 h-5" />,
      category: 'design',
      status: 'idle',
      component: ResponsiveTestRunner,
    },
    {
      id: 'fonts-icons',
      name: 'اختبار الخطوط والأيقونات',
      description: 'تحميل الخطوط وظهور الأيقونات',
      icon: <FileCode className="w-5 h-5" />,
      category: 'design',
      status: 'idle',
      component: FontsIconsTestRunner,
    },
    {
      id: 'accessibility',
      name: 'اختبار الوصولية',
      description: 'معايير WCAG والتنقل بالكيبورد',
      icon: <Activity className="w-5 h-5" />,
      category: 'interaction',
      status: 'idle',
      component: AccessibilityTestRunner,
    },
    {
      id: 'performance',
      name: 'اختبار الأداء البصري',
      description: 'قياس FPS وتأثير التصميم',
      icon: <Zap className="w-5 h-5" />,
      category: 'performance',
      status: 'idle',
      component: PerformanceTestRunner,
    },
    {
      id: 'charts',
      name: 'اختبار المخططات',
      description: 'Recharts وعرض البيانات',
      icon: <Activity className="w-5 h-5" />,
      category: 'interaction',
      status: 'idle',
      component: ChartsTest,
    },
    {
      id: 'dnd',
      name: 'اختبار Drag & Drop',
      description: 'React DnD والتفاعلات',
      icon: <TestTube className="w-5 h-5" />,
      category: 'interaction',
      status: 'idle',
      component: DnDTest,
    },
    {
      id: 'rtl',
      name: 'اختبار RTL',
      description: 'دعم اللغة العربية والاتجاه',
      icon: <FileCode className="w-5 h-5" />,
      category: 'design',
      status: 'idle',
      component: RTLTest,
    },
    {
      id: 'theme-toggle',
      name: 'اختبار تبديل الثيم',
      description: 'ThemeProvider وتبديل الألوان',
      icon: <Sun className="w-5 h-5" />,
      category: 'interaction',
      status: 'idle',
      component: ThemeTest,
    },
    {
      id: 'ui-components',
      name: 'اختبار مكونات UI',
      description: 'جميع مكونات Shadcn/ui',
      icon: <TestTube className="w-5 h-5" />,
      category: 'interaction',
      status: 'idle',
      component: UIComponentsTest,
    },
  ]);

  const [selectedTest, setSelectedTest] = useState<TestSuite | null>(null);

  const runTest = (testId: string) => {
    setTestSuites((prev) =>
      prev.map((test) =>
        test.id === testId ? { ...test, status: 'running' } : test
      )
    );

    // Simulate test execution
    setTimeout(() => {
      setTestSuites((prev) =>
        prev.map((test) =>
          test.id === testId
            ? { ...test, status: Math.random() > 0.1 ? 'passed' : 'failed' }
            : test
        )
      );
    }, 2000);
  };

  const runAllTests = () => {
    testSuites.forEach((test) => {
      runTest(test.id);
    });
  };

  const getStatusIcon = (status: TestStatus) => {
    switch (status) {
      case 'passed':
        return <CheckCircle2 className="w-4 h-4 text-success" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-destructive" />;
      case 'running':
        return <Clock className="w-4 h-4 text-warning animate-spin" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const filteredTests =
    selectedCategory === 'all'
      ? testSuites
      : testSuites.filter((test) => test.category === selectedCategory);

  const categoriesCount = {
    all: testSuites.length,
    design: testSuites.filter((t) => t.category === 'design').length,
    interaction: testSuites.filter((t) => t.category === 'interaction').length,
    performance: testSuites.filter((t) => t.category === 'performance').length,
    e2e: testSuites.filter((t) => t.category === 'e2e').length,
  };

  const passedTests = testSuites.filter((t) => t.status === 'passed').length;
  const failedTests = testSuites.filter((t) => t.status === 'failed').length;
  const runningTests = testSuites.filter((t) => t.status === 'running').length;

  return (
    <div className="min-h-screen bg-background p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1>🧪 CRM Nxs - مركز الاختبارات</h1>
            <p className="text-muted-foreground mt-2">
              اختبارات شاملة للتصميم، التفاعل، الأداء، والوصولية
            </p>
          </div>
          <Button onClick={runAllTests} className="gap-2">
            <Play className="w-4 h-4" />
            تشغيل جميع الاختبارات
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground mb-1">المجموع</p>
                <h3>{testSuites.length}</h3>
              </div>
              <TestTube className="w-8 h-8 text-primary opacity-20" />
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground mb-1">نجح</p>
                <h3 className="text-success">{passedTests}</h3>
              </div>
              <CheckCircle2 className="w-8 h-8 text-success opacity-20" />
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground mb-1">فشل</p>
                <h3 className="text-destructive">{failedTests}</h3>
              </div>
              <XCircle className="w-8 h-8 text-destructive opacity-20" />
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground mb-1">قيد التشغيل</p>
                <h3 className="text-warning">{runningTests}</h3>
              </div>
              <Clock className="w-8 h-8 text-warning opacity-20" />
            </div>
          </Card>
        </div>

        {/* Category Filters */}
        <div className="flex gap-2 flex-wrap">
          <Button
            variant={selectedCategory === 'all' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('all')}
            size="sm"
          >
            الكل ({categoriesCount.all})
          </Button>
          <Button
            variant={selectedCategory === 'design' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('design')}
            size="sm"
          >
            <Palette className="w-4 h-4 ml-2" />
            التصميم ({categoriesCount.design})
          </Button>
          <Button
            variant={selectedCategory === 'interaction' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('interaction')}
            size="sm"
          >
            <TestTube className="w-4 h-4 ml-2" />
            التفاعل ({categoriesCount.interaction})
          </Button>
          <Button
            variant={selectedCategory === 'performance' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('performance')}
            size="sm"
          >
            <Zap className="w-4 h-4 ml-2" />
            الأداء ({categoriesCount.performance})
          </Button>
          <Button
            variant={selectedCategory === 'e2e' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('e2e')}
            size="sm"
          >
            <Monitor className="w-4 h-4 ml-2" />
            E2E ({categoriesCount.e2e})
          </Button>
        </div>
      </div>

      {/* Test Grid */}
      <div className="max-w-7xl mx-auto">
        {selectedTest ? (
          <div className="space-y-4">
            <Button
              variant="outline"
              onClick={() => setSelectedTest(null)}
              className="mb-4"
            >
              ← العودة للقائمة
            </Button>
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  {selectedTest.icon}
                  <div>
                    <h2>{selectedTest.name}</h2>
                    <p className="text-muted-foreground">
                      {selectedTest.description}
                    </p>
                  </div>
                </div>
                <Button onClick={() => runTest(selectedTest.id)} size="sm">
                  <Play className="w-4 h-4 ml-2" />
                  تشغيل
                </Button>
              </div>
              <selectedTest.component />
            </Card>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTests.map((test) => (
              <Card
                key={test.id}
                className="p-4 hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => setSelectedTest(test)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    {test.icon}
                    <div>
                      <h4>{test.name}</h4>
                      <Badge variant="outline" className="mt-1">
                        {test.category}
                      </Badge>
                    </div>
                  </div>
                  {getStatusIcon(test.status)}
                </div>
                <p className="text-muted-foreground mb-3">{test.description}</p>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation();
                    runTest(test.id);
                  }}
                  disabled={test.status === 'running'}
                  className="w-full"
                >
                  <Play className="w-4 h-4 ml-2" />
                  {test.status === 'running' ? 'جاري التشغيل...' : 'تشغيل'}
                </Button>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
